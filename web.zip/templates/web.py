import sqlalchemy
from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
name = ''


class User(db.Model):
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    rank = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)

    def __repr__(self):
        return self.name


class Teacher(db.Model):
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name1 = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    password = sqlalchemy.Column(sqlalchemy.String, nullable=True)

    def __repr__(self):
        return f'{self.password}:{self.name1}'


@app.route('/')
def index():
    global name
    users = User.query.order_by(User.rank).all()
    return render_template('base.html', data=users, a=name)


@app.route('/kabinet')
def kabinet():
    return render_template('kabinet.html')


@app.route('/graf')
def graf():
    return render_template('graf.html')


@app.route('/ticket', methods=['POST', 'GET'])
def ticket():
    if request.method == 'POST':
        if request.form['name1'] != '':
            for i in range(len(User.query.all())):
                if str(User.query.all()[i]) == request.form['name1']:
                    ind = i
            try:
                db.session.delete(User.query.all()[ind])
                db.session.commit()
                a = '   '
                return render_template('ticket.html', a=a)
            except:
                a = 'ученика нет'
                return render_template('ticket.html', a=a)
    return render_template('ticket.html')


@app.route('/reg', methods=['POST', 'GET'])
def reg():
    if request.method == 'POST':
        if request.form['name1'] != '' and request.form['password'] != '':
            sp = []
            for i in Teacher.query.all():
                sp.append(str(i).split(':')[1])
            name1 = request.form['name1']
            password = request.form['password']
            if name1 not in sp:
                teacher = Teacher(name1=name1, password=password)
                try:
                    db.session.add(teacher)
                    db.session.commit()
                    a = '   '
                    return render_template('reg.html', a=a)
                except:
                    return 'ошибка'
            else:
                a = 'имя уже существует'
                return render_template('reg.html', a=a)
    return render_template('reg.html')


@app.route('/enter', methods=['POST', 'GET'])
def enter():
    if request.method == 'POST':
        if request.form['name1'] != '' and request.form['password'] != '':
            sp = []
            for i in Teacher.query.all():
                sp.append(str(i).split(':')[1])
            ind = sp.index(request.form['name1'])
            if f'''{request.form['password']}:{request.form['name1']}''' == str(Teacher.query.all()[ind]):
                global name
                name = request.form['name1']
                a = '    '
                return render_template('enter.html', a=a)
            else:
                a = 'неверный пароль'
                return render_template('enter.html', a=a)
    return render_template('enter.html')


@app.route('/add', methods=['POST', 'GET'])
def add():
    if request.method == 'POST':
        if request.form['name'] != '' and request.form['rank'] != '':
            name = request.form['name']
            rank = request.form['rank']
            user = User(name=name, rank=rank)
            try:
                db.session.add(user)
                db.session.commit()
                return redirect('/')
            except:
                return 'ошибка'
    return render_template('add.html')


if __name__ == '__main__':
    app.run(debug=True)